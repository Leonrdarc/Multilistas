/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multilistas;

/**
 *
 * @author leona
 */
public class Nodo_Hospital {
    String nombre;
    String direccion;
    int telefono;
    Nodo_Hospital link;

    public Nodo_Hospital(String nombre, String direccion, int telefono) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }
    
    public void agregar_Hospital(String nombre, String direccion, int telefono, Nodo_Hospital link){
        Nodo_Hospital p = new Nodo_Hospital(nombre, direccion, telefono);
    }

    public void setLink(Nodo_Hospital link) {
        this.link = link;
    }
    
}
